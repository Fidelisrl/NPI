package livros;

public class LivroFisico extends Livro {

    private int quantidadePaginas;

    public LivroFisico(String titulo, String autor, int ano, String codigo,
                        String identificacao, int quantidadePaginas) {
        super(titulo, autor, ano, codigo, identificacao);
        setQuantidadePaginas(quantidadePaginas);
    }

    public int getQuantidadePaginas() {
        return quantidadePaginas;
    }

    public void setQuantidadePaginas(int quantidadePaginas) {
        if (quantidadePaginas <= 0) {
            throw new IllegalArgumentException("A quantidade de páginas deve ser maior que zero.");
        }
        this.quantidadePaginas = quantidadePaginas;
    }

    @Override
    public void apresentarDados() {
        super.apresentarDados();
        System.out.println("Quantidade de páginas: " + quantidadePaginas);
    }

    public void folhear() {
        System.out.println("O livro \"" + getTitulo() + "\" está sendo folheado...");
    }
}
