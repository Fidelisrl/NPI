package locadora;

// TODO: adicionar Javadoc da classe.

/**
 * Responsável por gerenciar as operações de locação de veículos,
 * processamento de valores, descontos, multas e relatórios de frota
 * e clientes.
 */
public class Locadora {

    private static final double[] TABELA_PRECOS = {90.0, 130.0, 180.0};
    private static final int[] LIMIARES_DIAS = {3, 7, 15};
    private static final double[] DESCONTOS = {0.05, 0.10, 0.20};

    // Conta quantos carros da frota estao disponiveis.
    // TODO: adicionar Javadoc.

    /**
     * Conta quantos carros do array Carro estão disponíveis utlizando um loop que passa
     * pelo comprimento inteiro da array.
     * @param carros A lista de carros registrado na locadora.
     * @return A quantidade de carros disponíves na frota.
     */
    public int contarCarrosDisponiveis(Carro[] carros) {
        int total = 0;
        for (int i = 0; i < carros.length; i++) {
            if (carros[i].isDisponivel()) {
                total++;
            }
        }
        return total;
    }

    // Soma o valor da diaria de todos os carros da frota.
    // TODO: adicionar Javadoc.

    /**
     * Soma o valor da diária de todos os carros da frota, utilizando um loop que passa um
     * lenght para ler o valor de todas as diárias e depois soma elas na variável total.
     * @param carros A lista de carros registrados na locadora.
     * @return A soma do valor da diária de todos os carros
     */
    public double calcularReceitaTotalFrota(Carro[] carros) {
        double total = 0;
        for (int i = 0; i < carros.length; i++) {
            total += carros[i].getValorDiaria();
        }
        return total;
    }

    // Calcula a media de idade dos clientes informados.
    // TODO: adicionar Javadoc.

    /**
     * Calcula a média de idade dos clientes registrados na locadora utilizando um loop
     * que pega a lista da idade dos clientes e soma à variável soma que depois será
     * dividida pela quantidade de clientes.
     * @param clientes A lista de clientes da locadora.
     * @return A média de idade dos clientes.
     */
    public int calcularMediaIdadeClientes(Cliente[] clientes) {
        int soma = 0;
        for (int i = 0; i < clientes.length; i++) {
            soma += clientes[i].getIdade();
        }
        if(clientes.length == 0){
            return 0;
        }
        return soma / clientes.length;
    }

    // Busca, entre os clientes informados, o de maior idade.
    // TODO: adicionar Javadoc.

    /**
     * Busca qual é o cliente mais velho que a locadora possúi, puxando os clientes e fazendo
     * a verificação através de um loop.
     * @param clientes A lista de cliente da Locadora.
     * @return Retorna o cliente mais velho da locadora.
     */
    public Cliente buscarClienteMaisVelho(Cliente[] clientes) {
        Cliente maisVelho = null;
        if(clientes.length == 0){
            return new Cliente ("Não há clientes cadastrados", 0, 0);
        }
        for (int i = 0; i < clientes.length; i++) {
            if (maisVelho == null || clientes[i].getIdade() > maisVelho.getIdade()) {
                maisVelho = clientes[i];
            }
        }
        return maisVelho;
    }

    // Busca um carro pela placa e devolve uma descricao com modelo e valor da diaria.
    // TODO: adicionar Javadoc.

    /**
     * Busca um carro pela placa solicitada e devolve o modelo com o valor da diária do
     * veículo escolhido.
     * @param carros A lista de carros registrados na locadora.
     * @param placa A lista das placas dos carros registrados na locadora.
     * @return Retorna o modelo do veículo e o valor da sua diária.
     */
    public String buscarCarroPorPlaca(Carro[] carros, String placa) {
        Carro encontrado = null;
        for (int i = 0; i < carros.length; i++) {
            if (carros[i].getPlaca().equals(placa)) {
                encontrado = carros[i];
            }
        }
        if(encontrado == null){
            return "Nenhum carro encontrado com a placa " + placa;
        }
        return encontrado.getModelo() + " - R$" + encontrado.getValorDiaria() + "/dia";
    }

    // Calcula a multa por atraso, cobrando R$40,00 por dia de atraso.
    // TODO: adicionar Javadoc.

    /**
     * Calcula a multa baseado na quantidade de dias de atraso do pagamento,
     * cobrando 40 reais por dia.
     * @param diasAtraso Recebe a quantidade de dias de atraso para utilizar
     *                   no cálculo da multa.
     * @return Retorna a multa total.
     */
    public double calcularMultaAtraso(int diasAtraso) {
        double multaPorDia = 40;
        double total = 0;
        for (int i = 0; i < diasAtraso; i++) {
            total += multaPorDia;
        }
        return total;
    }

    // Processa uma locacao completa: valida o carro, calcula o valor bruto
    // (diaria + seguro, multiplicado pelos dias) e aplica 15% de desconto
    // quando o cliente estiver apto E o aluguel for de 7 dias ou mais.
    // TODO: adicionar Javadoc.

    /**
     * Processa uma locação completa, realizando a validação do veículo através
     * do metodo privado validarLocacao, calculando o valor bruto a partir
     * do metodo privado calcularValorBruto, que realiza a soma do valor da diária
     * com o valor diário do seguro e multiplica o resultado pela quantidade de dias
     * da locação. E por último aplica, ou não, os descontos devidos.
     * @param carro Recebe qual foi o carro escolhido para a locação, utilizado
     *              para realizar a verificação do veículo e no cálculo
     *              do valor bruto.
     * @param cliente Recebe qual o cliente que deseja realizar a locação,
     *                utilizado no metodo aplicarDescontosEEncargos, na
     *                condição "if", para verificar se haverá desconto
     *                de acordo com sua aptidão e seus anos de habilitação.
     * @param seguro Recebe o seguro que será utilizado.
     * @param dias Recebe a quantidade de dias que será realizado a locação.
     * @return Retorna o valor total da locação, sendo ele o valor bruto caso
     * o cliente não esteja apto, e o valor com o desconto de 15% caso esteja apto.
     */
    public double processarLocacaoCompleta(Carro carro, Cliente cliente, Seguro seguro, int dias) {
        validarLocacao(carro);
        double valorBruto = calcularValorBruto(carro, seguro, dias);
        return aplicarDescontosEEncargos(valorBruto, cliente, dias);
    }

    private void validarLocacao(Carro carro) {
        if (!carro.isDisponivel()) {
            throw new IllegalStateException("Carro indisponivel");
        }
    }

    private double calcularValorBruto(Carro carro, Seguro seguro, int dias) {
        return (carro.getValorDiaria() + seguro.getValorDiario()) * dias;
    }

    private double aplicarDescontosEEncargos(double valorBruto, Cliente cliente, int dias) {
        if (cliente.isApto() && dias >= 7) {
            return valorBruto * 0.85;
        }
        return valorBruto;
    }

    // Calcula a diaria de um aluguel a partir da categoria do veiculo (0, 1 ou 2),
    // multiplicada pela quantidade de dias.
    // TODO: adicionar Javadoc.

    /**
     * Calcula a diária de uma locação de acordo com a categoria escolhida
     * (0, 1 ou 2) da tabela de preços, realizando a multiplicação entre esse
     * valor e a quantidade de dias.
     * @param categoria Recebe qual a categoria escolhida (0, 1 ou 2)
     * @param dias Recebe a quantidade total de dias da locação.
     * @return Retora o total da diária com categoria (multiplicação do valor
     * pela quantidade de dias)
     */
    public double calcularDiariaComCategoria(int categoria, int dias) {
        if (categoria < 0 || categoria >= TABELA_PRECOS.length){
            throw new IllegalArgumentException("Categoria inválida: " + categoria);
        }
        if (dias <= 0){
            throw new IllegalArgumentException("A quantidade de dias deve ser maior que zero.");
        }
        double valorDiaria = TABELA_PRECOS[categoria];
        return valorDiaria * dias;
    }

    // Gera um resumo com a quantidade de carros disponiveis e o valor medio
    // da diaria apenas dos carros disponiveis.
    // TODO: adicionar Javadoc.

    /**
     * Gera o resumo da frota verificando a quantidade de carros disponíveis,
     * somando os valores da diária de todos eles e calculando a média final.
     * @param carros Recebe o array Carros contendo os veículos a serem
     *               analisados.
     * @return Retorna a quantidade de carros disponíveis, e a média de seus valores
     * por dia.
     */
    public String gerarResumoFrota(Carro[] carros) {
        if (carros == null || carros.length == 0){
            return "Não há carro(s) disponivel(is), média de R$" + String.format("%.2f", 0.0) + "/dia";
        }

        int disponiveis = 0;
        double somaValores = 0;
        for (int i = 0; i < carros.length; i++) {
            if (carros[i].isDisponivel()) {
                disponiveis++;
                somaValores += carros[i].getValorDiaria();
            }
        }
        double media = disponiveis == 0 ? 0 : somaValores / disponiveis;
        return disponiveis + " carro(s) disponivel(is), media de R$" + String.format("%.2f", media) + "/dia";
    }

    // Aplica um desconto escalonado sobre o valor base, conforme a quantidade
    // de dias alugados: 5% (3+ dias), 10% (7+ dias) ou 20% (15+ dias).
    // TODO: adicionar Javadoc.

    /**
     * Calcula o desconto escalonado, utilizando um valor base e uma quantidade de
     * dias. Dependendo da quantidade de dias, é descontado uma certa porcentagem
     * do valor base.
     * Os descontos podem ser: 5% (3+ dias), 10% (7+ dias) ou 20% (15+ dias).
     * @param valorBase Recebe o valor base que terá o desconto aplicado.
     * @param dias Recebe a quantidade de dias, para saber qual desconto deve
     *             ser aplicado.
     * @return Retorna o valor já com o desconto aplicado.
     */
    public double calcularDescontoEscalonado(double valorBase, int dias) {
        double desconto = 0;
        for (int i = 0; i < LIMIARES_DIAS.length; i++) {
            if (dias >= LIMIARES_DIAS[i]) {
                desconto = DESCONTOS[i];
            }
        }
        return valorBase * (1 - desconto);
    }

    // Verifica se o cliente tem direito ao desconto de fidelidade: precisa ter
    // pelo menos 25 anos E pelo menos 3 locacoes anteriores.
    // TODO: adicionar Javadoc.

    /**
     * Verifica e apresenta se o cliente analisado é elegível para o
     * desconto de fidelidade. Para que seja, ele deve ter 25 anos ou
     * mais, e ter feito pelo menos 3 locações anteriores. Caso contrário,
     * não será elegível.
     * @param cliente Recebe qual o cliente que deverá ser verificado para
     *                elegibilidade.
     * @param totalLocacoesAnteriores Recebe a quantidade de locações feitas
     *                                por esse cliente anteriormente.
     * @return Retorna se o cliente analisado é elegível ao desconto ou não,
     * apresentando na tela "true" (verdadeiro) ou "false" (falso).
     */
    public boolean clienteElegivelDescontoFidelidade(Cliente cliente, int totalLocacoesAnteriores) {
        return cliente.getIdade() >= 25 && totalLocacoesAnteriores >= 3;
    }
}
