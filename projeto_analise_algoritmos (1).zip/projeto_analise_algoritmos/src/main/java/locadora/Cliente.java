package locadora;

// TODO: adicionar Javadoc da classe.

/**
 * Essa classe armazena os dados do cliente da locadora.
 * Guarda o nome, a idade e o tempo em anos que o cliente é habilitado.
 */
public class Cliente {

    private String nome;
    private int idade;
    private int anosHabilitado;

    // TODO: adicionar Javadoc do construtor.

    /**
     * Cria um Cliente novo.
     * @param nome Nome do cliente.
     * @param idade Idade do cliente.
     * @param anosHabilitado Tempo em Anos de habilitação.
     */
    public Cliente(String nome, int idade, int anosHabilitado) {
        this.nome = nome;
        this.idade = idade;
        this.anosHabilitado = anosHabilitado;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public int getAnosHabilitado() {
        return anosHabilitado;
    }

    // TODO: adicionar Javadoc.

    /**
     * Verifica se o cliente é apto para alugar um carro analisando a idade e o tempo de habilitação.
     * @return retorna true caso esteja apto (Tenha pelo menos 21 anos e é habilitado por pelo menos
     * 2 anos); retorna false caso essa condição não seja verdadeira.
     */
    public boolean isApto() {
        return idade >= 21 && anosHabilitado >= 2;
    }
}
