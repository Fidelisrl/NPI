package usuarios;

import livros.Livro;

public class Usuario {

    private String nome;
    private String matricula;

    public Usuario(String nome, String matricula) {
        setNome(nome);
        setMatricula(matricula);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome não pode ficar vazio.");
        }
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        if (matricula == null || matricula.trim().isEmpty()) {
            throw new IllegalArgumentException("A matrícula não pode ficar vazia.");
        }
        this.matricula = matricula;
    }

    // ASSOCIAÇÃO SIMPLES: recebe um Livro só como parâmetro do método,
    // não guarda referência dele como atributo -> vínculo fraco/temporário
    public void realizarEmprestimo(Livro livro) {
        System.out.println("Usuário " + nome + " (matrícula " + matricula
                + ") realizou o empréstimo do livro \"" + livro.getTitulo() + "\".");
    }
}
