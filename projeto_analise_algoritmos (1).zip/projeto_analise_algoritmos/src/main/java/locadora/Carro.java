package locadora;

// TODO: adicionar Javadoc da classe.

/**
 * Essa Classe armazena os dados do carro para locação.
 * Guarda a placa, o modelo, o valor da diária e a disponibilidade.
 */
public class Carro {

    private String placa;
    private String modelo;
    private double valorDiaria;
    private boolean disponivel;

    // TODO: adicionar Javadoc do construtor.

    /**
     * Cria um carro novo, que é marcado como disponível por padrão.
     * @param placa Placa do carro.
     * @param modelo Modelo do carro.
     * @param valorDiaria Valor da diária do carro.
     */
    public Carro(String placa, String modelo, double valorDiaria) {
        this.placa = placa;
        this.modelo = modelo;
        this.valorDiaria = valorDiaria;
        this.disponivel = true;
    }

    public String getPlaca() {
        return placa;
    }

    public String getModelo() {
        return modelo;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
}
