package livros;

// HERANÇA: extends Livro
public class LivroDigital extends Livro {

    private double tamanhoArquivo;

    public LivroDigital(String titulo, String autor, int ano, String codigo,
                         String identificacao, double tamanhoArquivo) {
        // super() inicializa os atributos herdados da classe Livro
        super(titulo, autor, ano, codigo, identificacao);
        setTamanhoArquivo(tamanhoArquivo);
    }

    public double getTamanhoArquivo() {
        return tamanhoArquivo;
    }

    public void setTamanhoArquivo(double tamanhoArquivo) {
        if (tamanhoArquivo <= 0) {
            throw new IllegalArgumentException("O tamanho do arquivo deve ser maior que zero.");
        }
        this.tamanhoArquivo = tamanhoArquivo;
    }

    // SOBRESCRITA (override) do método da superclasse
    @Override
    public void apresentarDados() {
        super.apresentarDados();
        System.out.println("Tamanho do arquivo: " + tamanhoArquivo + " MB");
    }

    // método específico da subclasse
    public void baixar() {
        System.out.println("O livro digital \"" + getTitulo() + "\" está sendo baixado...");
    }
}
