package principal;

import livros.Livro;
import livros.LivroDigital;
import livros.LivroFisico;
import usuarios.Usuario;
import biblioteca.Biblioteca;

public class Principal {

    public static void main(String[] args) {

        // POLIMORFISMO: variável do tipo Livro (superclasse) apontando
        // para objetos das subclasses
        Livro livro1 = new LivroDigital("Clean Code", "Robert C. Martin", 2008,
                "LD001", "Digital-01", 4.5);
        Livro livro2 = new LivroFisico("Effective Java", "Joshua Bloch", 2018,
                "LF001", "Fisico-01", 412);

        // Usuario criado separadamente
        Usuario usuario1 = new Usuario("Felipe Monma", "2024001");

        // Biblioteca criada, depois relacionada ao usuário (agregação)
        Biblioteca biblioteca = new Biblioteca("Biblioteca Central", "Londrina");
        biblioteca.setUsuario(usuario1);

        // Associação simples: usuário recebe um Livro só como parâmetro do método
        usuario1.realizarEmprestimo(livro1);

        System.out.println("\n--- apresentarDados() (polimorfismo) ---");
        livro1.apresentarDados(); // executa a versão de LivroDigital
        livro2.apresentarDados(); // executa a versão de LivroFisico

        System.out.println("\n--- toString() ---");
        System.out.println(livro1);
        System.out.println(livro2);

        System.out.println("\n--- Métodos sobrecarregados ---");
        livro1.exibirMensagem();
        livro1.exibirMensagem("Reserva confirmada para o livro digital.");

        System.out.println("\n--- Métodos específicos das subclasses ---");
        ((LivroDigital) livro1).baixar();
        ((LivroFisico) livro2).folhear();

        System.out.println("\n--- Getters e setters (sem alterar atributos direto) ---");
        livro1.setAno(2009);
        System.out.println("Novo ano do livro1: " + livro1.getAno());

        System.out.println("\nBiblioteca " + biblioteca.getNome() + " (" + biblioteca.getCidade()
                + ") tem como usuário: " + biblioteca.getUsuario().getNome());
    }
}
