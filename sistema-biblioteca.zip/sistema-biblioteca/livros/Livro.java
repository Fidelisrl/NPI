package livros;

public class Livro {

    // atributos privados -> acesso controlado só por getters/setters
    private String titulo;
    private String autor;
    private int ano;

    // COMPOSIÇÃO: CodigoLivro só existe enquanto Livro existir,
    // e é criado DENTRO do construtor do Livro (nunca na Principal)
    private CodigoLivro codigoLivro;

    public Livro(String titulo, String autor, int ano, String codigo, String identificacao) {
        setTitulo(titulo);
        setAutor(autor);
        setAno(ano);
        this.codigoLivro = new CodigoLivro(codigo, identificacao);
    }

    // ---- getters e setters (com validação das regras da prova) ----
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new IllegalArgumentException("O título não pode ficar vazio.");
        }
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        if (autor == null || autor.trim().isEmpty()) {
            throw new IllegalArgumentException("O autor não pode ficar vazio.");
        }
        this.autor = autor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        if (ano <= 0) {
            throw new IllegalArgumentException("O ano deve ser maior que zero.");
        }
        this.ano = ano;
    }

    public CodigoLivro getCodigoLivro() {
        return codigoLivro;
    }

    // método pedido no enunciado
    public void apresentarDados() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Ano: " + ano);
        System.out.println("Código: " + codigoLivro.getCodigo()
                + " | Identificação: " + codigoLivro.getIdentificacao());
    }

    // SOBRECARGA (overload): mesmo nome, assinaturas diferentes
    public void exibirMensagem() {
        System.out.println("[Aviso] Este é um item do acervo da biblioteca.");
    }

    public void exibirMensagem(String mensagem) {
        System.out.println("[Aviso] " + mensagem);
    }

    @Override
    public String toString() {
        return "Livro{" +
                "titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", ano=" + ano +
                ", codigo=" + codigoLivro.getCodigo() +
                '}';
    }
}
