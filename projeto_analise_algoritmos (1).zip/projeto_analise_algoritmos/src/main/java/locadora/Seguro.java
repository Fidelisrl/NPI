package locadora;

// TODO: adicionar Javadoc da classe.

/**
 * Representa um seguro disponível para ser contratado com a locação.
 * Armazena o tipo de seguro e o valor diário dele.
 */
public class Seguro {

    private String tipo;
    private double valorDiario;

    // TODO: adicionar Javadoc do construtor.

    /**
     * Cria um novo tipo de seguro e o valor diário dele.
     * @param tipo Tipo do seguro (Ex: básico).
     * @param valorDiario O valor diário do seguro.
     */
    public Seguro(String tipo, double valorDiario) {
        this.tipo = tipo;
        this.valorDiario = valorDiario;
    }

    public String getTipo() {
        return tipo;
    }

    public double getValorDiario() {
        return valorDiario;
    }
}
