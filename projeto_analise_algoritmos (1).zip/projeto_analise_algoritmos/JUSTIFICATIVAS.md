# Justificativas — Parte 1 (Depuração)

Preencha uma seção para cada um dos 11 métodos da classe `Locadora`. Para cada um,
diga se ele tinha um bug ou não, e então explique o que estava
errado e por que a sua correção resolve o problema (ou explique por que
decidiu que o método já estava correto).
Se for fazer em dupla, cada aluno coloca aqui nesse arquivo quais respondeu.

## 1. contarCarrosDisponiveis

**Tinha bug?**
Não, não tinha.

**Explicação:**
Quando executa o código ele devolve que tem 3 carros disponíveis, e está correto, pois na main
foi setado como false o carro do íncide 1, que corresponde ao corolla, logo realmente
existem 3 carros disponíveis.

**Respondido por:**
Felipe Fidelis.

## 2. calcularReceitaTotalFrota

**Tinha bug?**
Sim, tinha bug.

**Explicação:**
Quando o código é executado está voltando a soma dos 3 últimos carros, então para corrigir e somar
os 4 carros, tive que alterar o valor de i, que antes iniciava no 1, para 0, agora começando no 0 e
somando os 4 carros.

**Respondido por:**
Felipe Fidelis.

## 3. calcularMediaIdadeClientes

**Tinha bug?**
Sim, tinha bug.

**Explicação:**
Por não ter nenhum cliente registrado, estava dando erro pois não é possível dividir por zero. 
Para resolver eu adicionei uma estrutura de decisão que caso não tenha clientes registrados
a média devolvida será 0 e não será necessário dividir.

**Respondido por:**
Felipe Fidelis.

## 4. buscarClienteMaisVelho

**Tinha bug?**
Na forma nativa da Main não, mas caso colocasse os clientes novos daria.

**Explicação:**
Por na main não ter nenhum cliente na lista de clientes novos, o código anterior daria erro.
Para corrigir isso eu adicinei uma estrutura de decisão para que caso ela estivesse sem nada
retornar que não há clientes registrados.

**Respondido por:**
Felipe Fidelis.

## 5. buscarCarroPorPlaca

**Tinha bug?**
Sim, tinha bug.

**Explicação:**
Estava dando erro porque quando não tinha nenhum carro com a placa correspondente o código 
crashava porque dava null. Para resolver adicinei uma estrutura de decisão e caso der null
retorna que não tem nenhum carro com a placa informada.

**Respondido por:**
Felipe Fidelis.

## 6. calcularMultaAtraso

**Tinha bug?**
Sim, havia bug.

**Explicação:**
O cálculo estava retornando um resultado incorreto, pois no
laço de repetição o contador ia de 0 até ser < ou = aos dias de atraso.
Ou seja, se forem 3 dias de atraso, o laço repetirá 4 vezes (0, 1, 2, 3),
e ele deveria repetir apenas 3 vezes (0, 1, 2), para isso, corrigi o laço
para i < diasAtraso.

**Respondido por:**
Mariane Maicá Silveira.

## 7. processarLocacaoCompleta

**Tinha bug?**
Sim, havia bug.

**Explicação:**
O método processarLocacaoCompleta calculava o valorBruto corretamente através
do método calcularValorBruto(carro, seguro, dias), porém o seu retorno sempre
retornaria um resultado incorreto pois dentro do método aplicarDescontosEEncargos
(valorBruto, cliente, dias) a condição "if" estava como (cliente.isApto() || dias >= 7),
ou seja, se um fosse verdadeiro, o desconto já seria aplicado, o que é um equivoco visto
que a condição correta solicitava que ambas as condições fossem cumpridas.
Para corrigir isso, troquei o operador || (ou) para o operador && (e).

**Respondido por:**
Mariane Maicá Silveira.

## 8. calcularDiariaComCategoria

**Tinha bug?**
Não, não havia bug.

**Explicação:**
Não havia bug propriamente aparente, porém não havia um tratamento específico
para caso fosse passada uma categoria inválida, como por exemplo categoria -1.
Isso ocasionaria um erro durante a execução do código ao tentar acessar
TABELA_PRECOS[categoria]. Para isso, adicionei duas estruturas condicionais,
uma para verificar se a categoria existe na tabela de preços, e outra para
verificar se a quantidade de dias é válida (deve ser maior que 0).

**Respondido por:**
Mariane Maicá Silveira.

## 9. gerarResumoFrota

**Tinha bug?**
Não, não havia bug.

**Explicação:**
Não possuía bug propriamente aparente, verificava a quantidade de carros 
disponíveis e calculava a média da soma de seus valores por dia corretamente.
Porém, não havia tratamento para o caso de passar uma array (lista) de carros
vazia. Para isso, criei uma estrutura condicional simples para verificar se
o array é nulo, e caso verifique-se que sim, retorne que não há carros dispo-
níveis e a média é de 0 reais por dia.

**Respondido por:**
Mariane Maicá Silveira.

## 10. calcularDescontoEscalonado

**Tinha bug?**
Sim, havia bug.

**Explicação:**
Durante a execução do código, caso o usuário escolhesse esta opção 10,
um erro era apresentado na tela, e a execução interrompia-se.
O erro apresentao era ArrayIndexOutOfBoundsException, que devia-se
à tentativa de acesso ao LIMIARES_DIAS[3], índice não existente, visto
que o array é acessado por 0, 1 e 2.
Para isso, corrigi o laço de repetição, trocando i <= LIMIARES_DIAS.length
para i < LIMIARES_DIAS.length, o que impede que ele tente acessar um índice
inexistente.

**Respondido por:**
Mariane Maicá Silveira.

## 11. clienteElegivelDescontoFidelidade

**Tinha bug?**
Sim, havia bug.

**Explicação:**
Durante a execução do código, se o usuário escolhesse a opção 11
aparecia a mensagem correta de verificação, porém apresentava o 
resultado de "Elegível?" incorretamente. 
Isso devia-se ao fato de que no método, o retorno apenas
daria verdadeiro (true) se o cliente tivesse mais que 25 anos e
pelo menos 3 locações anteriores. Porém, o correto era ser ver-
dadeiro caso o cliente tivesse PELO MENOS 25 anos, ou seja, 25 anos
ou mais, e pelo menos 3 locações anteriores.
Para corrigir, alterei o cliente.getIdade() > 25 para
cliente.getIdade() >= 25.

**Respondido por:**
Mariane Maicá Silveira.
