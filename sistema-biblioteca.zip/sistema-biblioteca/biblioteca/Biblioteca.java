package biblioteca;

import usuarios.Usuario;

public class Biblioteca {

    private String nome;
    private String cidade;

    // AGREGAÇÃO: Biblioteca só guarda uma referência.
    // O Usuario é criado FORA (na Principal) e só depois é associado aqui.
    // Se a Biblioteca "morrer", o Usuario continua existindo normalmente.
    private Usuario usuario;

    public Biblioteca(String nome, String cidade) {
        this.nome = nome;
        this.cidade = cidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    // aqui é onde a agregação acontece: recebe um usuário já pronto
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
